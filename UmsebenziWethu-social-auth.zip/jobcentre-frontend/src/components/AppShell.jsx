import {
  Bell,
  BriefcaseBusiness,
  CalendarClock,
  FileCheck2,
  Heart,
  Home,
  LogOut,
  Menu,
  MessageSquareText,
  PlusCircle,
  Settings,
  ShieldCheck,
  UserRound,
  UsersRound,
  X,
} from "lucide-react";
import { useState } from "react";
import { NavLink, Outlet } from "react-router-dom";
import { useAuth } from "../state/AuthContext";
import SiteFooter from "./SiteFooter";
import UserAvatar from "./UserAvatar";
import { JOB_CATEGORIES } from "../data/jobCategories";
import SafetyNotice from "./SafetyNotice";

const linkClass = ({ isActive }) =>
  `nav-link ${isActive ? "active" : ""}`;

export default function AppShell() {
  const { user, logout, avatarRevision } = useAuth();
  const [mobileMoreOpen, setMobileMoreOpen] = useState(false);

  return (
    <>
      <header className="topbar">
        <NavLink to="/" className="brand">
          <img
            className="brand-logo"
            src="/images/logo.png"
            alt="UmsebenziWethu Job Market"
          />

          <span className="brand-name">
            UmsebenziWethu
            <b>Job Market</b>
          </span>
        </NavLink>

        <div className="top-actions">
          {user?.role === "employer" && (
            <button
              type="button"
              className="icon-button mobile-menu-toggle"
              onClick={() => setMobileMoreOpen(true)}
              aria-label="Open employer navigation"
              aria-expanded={mobileMoreOpen}
              aria-controls="employer-mobile-more"
            >
              <Menu />
            </button>
          )}

          {user ? (
            <>
              <NavLink
                to="/profile"
                className="user-chip"
                aria-label="Open your profile"
              >
                <UserAvatar
                  user={user}
                  className="nav-avatar"
                  cacheKey={avatarRevision}
                />

                <span className="user-name">
                  {user.first_name || user.username}
                </span>
              </NavLink>

              <button
                type="button"
                className="icon-button"
                onClick={logout}
                aria-label="Log out"
              >
                <LogOut size={20} />
              </button>
            </>
          ) : (
            <>
              <NavLink to="/login" className="button ghost">
                Log in
              </NavLink>

              <NavLink to="/register" className="button primary">
                Join
              </NavLink>
            </>
          )}
        </div>
      </header>

      <div className="page-grid">
        <aside className="sidebar left-sidebar">
          <nav aria-label="Main navigation">
            <NavLink className={linkClass} to="/">
              <Home />
              Home
            </NavLink>

            {user?.role === "job_seeker" && (
              <>
                <NavLink className={linkClass} to="/saved">
                  <Heart />
                  Saved jobs
                </NavLink>

                <NavLink className={linkClass} to="/applications">
                  <FileCheck2 />
                  Applications
                </NavLink>
              </>
            )}

            {user?.role === "employer" && (
              <>
                <NavLink className={linkClass} to="/employer">
                  <BriefcaseBusiness />
                  My jobs
                </NavLink>

                <NavLink className={linkClass} to="/applicants">
                  <UsersRound />
                  Applicants
                </NavLink>

                <NavLink className={linkClass} to="/job-seekers">
                  <UserRound />
                  Job seekers
                </NavLink>

                <NavLink className={linkClass} to="/post-job">
                  <PlusCircle />
                  Post a job
                </NavLink>
              </>
            )}

            {user && (
              <>
                <NavLink className={linkClass} to="/interviews">
                  <CalendarClock />
                  Interview Hub
                </NavLink>

                <NavLink className={linkClass} to="/notifications">
                  <Bell />
                  Notifications
                </NavLink>

                <NavLink className={linkClass} to="/profile">
                  <UserRound />
                  Profile
                </NavLink>

                <NavLink className={linkClass} to="/settings">
                  <Settings />
                  Settings
                </NavLink>
              </>
            )}

            <NavLink className={linkClass} to="/feedback">
              <MessageSquareText />
              Feedback
            </NavLink>
            <NavLink className={linkClass} to="/safety">
              <ShieldCheck />
              Safety Centre
            </NavLink>
          </nav>

          <SafetyNotice variant="compact" />
        </aside>

        <main className="main-content">
          <Outlet />
        </main>

        <aside className="sidebar right-sidebar">
          <section className="side-card">
            <h3>Browse job categories</h3>
            <p className="category-helper">Explore opportunities across growing and essential sectors.</p>
            <div className="category-links">
            {JOB_CATEGORIES.map((category) => (
              <NavLink
                key={category.value}
                to={`/?search=${encodeURIComponent(category.query)}`}
              >
                {category.value}
              </NavLink>
            ))}
            </div>
            <NavLink className="all-jobs-link" to="/" end>View all opportunities →</NavLink>
          </section>

          <section className="side-card">
            <h3>Job Centre promise</h3>
            <p>
              Fresh opportunities, clear closing dates and safer
              employer communication.
            </p>
          </section>
        </aside>
      </div>

      <SiteFooter />

      {user?.role === "employer" ? (
        <>
          <nav
            className="bottom-nav employer-bottom-nav"
            aria-label="Employer mobile navigation"
          >
            <NavLink className={linkClass} to="/employer">
              <BriefcaseBusiness />
              <span>My jobs</span>
            </NavLink>

            <NavLink className={linkClass} to="/applicants">
              <UsersRound />
              <span>Applicants</span>
            </NavLink>

            <NavLink className={linkClass} to="/post-job">
              <PlusCircle />
              <span>Post</span>
            </NavLink>

            <NavLink className={linkClass} to="/interviews">
              <CalendarClock />
              <span>Interviews</span>
            </NavLink>

            <button
              type="button"
              className={`nav-link ${
                mobileMoreOpen ? "active" : ""
              }`}
              onClick={() => setMobileMoreOpen(true)}
              aria-expanded={mobileMoreOpen}
              aria-controls="employer-mobile-more"
            >
              <Menu />
              <span>More</span>
            </button>
          </nav>

          {mobileMoreOpen && (
            <>
              <button
                type="button"
                className="mobile-more-backdrop"
                aria-label="Close employer menu"
                onClick={() => setMobileMoreOpen(false)}
              />

              <section
                id="employer-mobile-more"
                className="mobile-more-panel"
                role="dialog"
                aria-modal="true"
                aria-label="More employer navigation"
              >
                <header>
                  <div>
                    <strong>Employer menu</strong>
                    <small>Account, updates and support</small>
                  </div>

                  <button
                    type="button"
                    className="icon-button"
                    onClick={() => setMobileMoreOpen(false)}
                    aria-label="Close menu"
                  >
                    <X />
                  </button>
                </header>

                <nav>
                  <NavLink
                    className={linkClass}
                    to="/"
                    onClick={() => setMobileMoreOpen(false)}
                  >
                    <Home />
                    <span>Home</span>
                  </NavLink>

                  <NavLink
                    className={linkClass}
                    to="/employer"
                    onClick={() => setMobileMoreOpen(false)}
                  >
                    <BriefcaseBusiness />
                    <span>My jobs</span>
                  </NavLink>

                  <NavLink
                    className={linkClass}
                    to="/applicants"
                    onClick={() => setMobileMoreOpen(false)}
                  >
                    <UsersRound />
                    <span>Applicants</span>
                  </NavLink>

                  <NavLink
                    className={linkClass}
                    to="/job-seekers"
                    onClick={() => setMobileMoreOpen(false)}
                  >
                    <UserRound />
                    <span>Job seekers</span>
                  </NavLink>

                  <NavLink
                    className={linkClass}
                    to="/post-job"
                    onClick={() => setMobileMoreOpen(false)}
                  >
                    <PlusCircle />
                    <span>Post a job</span>
                  </NavLink>

                  <NavLink
                    className={linkClass}
                    to="/interviews"
                    onClick={() => setMobileMoreOpen(false)}
                  >
                    <CalendarClock />
                    <span>Interview Hub</span>
                  </NavLink>

                  <NavLink
                    className={linkClass}
                    to="/notifications"
                    onClick={() => setMobileMoreOpen(false)}
                  >
                    <Bell />
                    <span>Notifications</span>
                  </NavLink>

                  <NavLink
                    className={linkClass}
                    to="/profile"
                    onClick={() => setMobileMoreOpen(false)}
                  >
                    <UserRound />
                    <span>Profile</span>
                  </NavLink>

                  <NavLink
                    className={linkClass}
                    to="/settings"
                    onClick={() => setMobileMoreOpen(false)}
                  >
                    <Settings />
                    <span>Settings</span>
                  </NavLink>

                  <NavLink
                    className={linkClass}
                    to="/feedback"
                    onClick={() => setMobileMoreOpen(false)}
                  >
                    <MessageSquareText />
                    <span>Feedback</span>
                  </NavLink>

                  <NavLink
                    className={linkClass}
                    to="/safety"
                    onClick={() => setMobileMoreOpen(false)}
                  >
                    <ShieldCheck />
                    <span>Safety Centre</span>
                  </NavLink>
                </nav>
              </section>
            </>
          )}
        </>
      ) : user?.role === "job_seeker" ? (
        <nav
          className="bottom-nav interview-bottom-nav"
          aria-label="Job-seeker mobile navigation"
        >
          <NavLink className={linkClass} to="/">
            <Home />
            <span>Home</span>
          </NavLink>

          <NavLink className={linkClass} to="/applications">
            <FileCheck2 />
            <span>Applied</span>
          </NavLink>

          <NavLink className={linkClass} to="/interviews">
            <CalendarClock />
            <span>Interviews</span>
          </NavLink>

          <NavLink className={linkClass} to="/saved">
            <Heart />
            <span>Saved</span>
          </NavLink>

          <NavLink className={linkClass} to="/safety">
            <ShieldCheck />
            <span>Safety</span>
          </NavLink>
        </nav>
      ) : (
        <nav
          className="bottom-nav guest-bottom-nav"
          aria-label="Guest mobile navigation"
        >
          <NavLink className={linkClass} to="/">
            <Home />
            <span>Home</span>
          </NavLink>

          <NavLink className={linkClass} to="/feedback">
            <MessageSquareText />
            <span>Feedback</span>
          </NavLink>

          <NavLink className={linkClass} to="/safety">
            <ShieldCheck />
            <span>Safety</span>
          </NavLink>

          <NavLink className={linkClass} to="/login">
            <UserRound />
            <span>Log in</span>
          </NavLink>
        </nav>
      )}
    </>
  );
}
